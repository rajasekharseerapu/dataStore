import os
import csv

from flask import Flask, request, render_template, redirect

app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.after_request
def add_header(r):
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r

@app.route('/')
def index():
    return render_template("upload.html")

@app.route("/upload",methods=['POST'])
def upload():
    target = os.path.join(APP_ROOT, 'myfiles/')
    print(target)

    if not os.path.isdir(target):
        os.mkdir(target)

    for file in request.files.getlist("file"):
        print(file)
        filename = file.filename
        row_contents = [filename, request.form['expl'], file.read()]
        with open('static/dataStore.csv', 'a+b') as write_obj:
            csv_writer = csv.writer(write_obj,delimiter=',')
            csv_writer.writerow(row_contents)

        destination = "/".join([target, filename])
        print(destination)
        file.save(destination)

    return redirect("/")

if __name__ == '__main__':
    app.run(port=5000, debug=True)
